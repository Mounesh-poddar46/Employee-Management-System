<html>
</style>
<head>  

<title> Welcome!</title>  

<meta charset="utf-8">
  
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">


<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">

<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
</script>



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
</script>
  
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>


</head>  

<body style='background:gray;'>
<nav class="navbar bg-info">
  
<div class="container-fluid">
    
<div class="navbar-header">
      
<a class="navbar-brand" href="#">Employee Management</a>
    
</div>
    
<ul class="nav navbar-nav navbar-left">
      
<li class="active"><a href="http://localhost/my%20php/emp_info.php">Home</a></li>
     
<li><a href="http://localhost/my%20php/insertemploye.php">Insert</a></li>
      
<li><a href="http://localhost/my%20php/searchemploye.php">Search</a></li>
      
<li><a href="http://localhost/my%20php/update.php">Update</a></li>
      
<li><a href="http://localhost/my%20php/delete.php">Delete</a></li>

</ul>






<form class="navbar-form navbar-left" action="/action_page.php">
      
<div class="form-group">
        
<input type="text" class="form-control" placeholder="Search">
      
</div>
      <button type="submit" class="btn btn-default">Submit</button>
    
</form>


 </div>

</nav>
<center>
<h1 style='background:orange; color:whitesmoke;'</h1>





<hr>
<form action="" method="POST">
<table border=5 cellpadding=5 cellspacing=5 style="border-radius:10px 10px 10px 10px; background:khaki; color:blue; border-color:green;">
<tr>
<td>User Name:</td>
<td><input type="text" id="username" name="username" place
holder="Username" required/></td></tr>

<tr><td>Password:</td>
<td><input id="password" name="password" type="password" required/></td></tr>

<tr><td>Confirm Password:</td>
<td><input id="confirmpassword" name="confirmpassword" type="password" required/></td></tr>
<tr><td colspan=2><input type="submit" name="submit" value="register" style="border-radius:10px 10px 10px 10px; background:khaki;\
color:blue; border-color:green;">Already have an user account?<a href="http://localhost/myphp/login.php">Click here</a></td></tr>
</table>
</form>
</body>
</html>

<?php
require('config.php');

if(isset($_POST['username'])&& isset($_POST['password'])){
$username = $_POST['username'];
$username = $_POST['password'];
$username = $_POST['confirmpassword'];

$slquery="SELECT 1 FROM users WHERE user='$username'";
$selectresult=mysql_query($slquery);

if(mysql_num_rows($selectresult)>0)
{
$msg='user already exists';

echo"<h1 style='background:red; color:white'>",$msg,"</h1>";
}
else if($password !=$cpassword){
$msg="passwords doesn't match";
echo"<h1 style='background:orange; color:teal'>",$msg,"</h1>";
}
else{
$query="INSERT INTO users (user,passw) VALUES ('$username','$password')";
$result=mysql_query($query);
if($result){
$msg="User Created Successfully.";
echo "<h1 style='background:green; color:white'>",$msg,"</h1>";
}
}
}
?>
<h6><a href="welcome.php"><button type="button" class="btn btn-danger">Back</button></a></h6>
<br><br><br><br><br><br><br><br>
<h1 style=background:greenyellow; color:skyblue;'>by MIT India</h1>