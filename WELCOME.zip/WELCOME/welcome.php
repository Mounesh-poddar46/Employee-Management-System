<?php  

session_start(); 

  if(!$_SESSION['email'])  

{  
header("Location: login.php");
}  

?>  

 
<html>
<style>
body{background-image:conic-gradient(lightblue,lightblue);}
</style>
<head>  

<title> Welcome!</title>  

<meta charset="utf-8">
  
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">


<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">

<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
</script>



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
</script>
  
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js">
</script>


</head>  

  <center>

<body> 

<nav class="navbar bg-info">
  
<div class="container-fluid">
    
<div class="navbar-header">
      
<a class="navbar-brand" href="#">Employee Management</a>
    
</div>
    
<ul class="nav navbar-nav">
      
<li class="active"><a href="http://localhost/my%20php/emp_info.php">Home</a></li>
     
<li><a href="http://localhost/my%20php/insert.php">Insert</a></li>
      
<li><a href="http://localhost/my%20php/searchemploye.php">Search</a></li>
      
<li><a href="http://localhost/my%20php/update.php">Update</a></li>
      
<li><a href="http://localhost/my%20php/delete.php">Delete</a></li>

</ul>


<ul class="nav navbar-nav navbar-right">
      
<li><a href="http://localhost/my%20php/regUser.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      
<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>

</ul>



<form class="navbar-form navbar-left" action="/action_page.php">
      
<div class="form-group">
        
<input type="text" class="form-control" placeholder="Search">
      
</div>
      <button type="submit" class="btn btn-default">Submit</button>
    
</form>


 </div>

</nav>


<h2 class="bg-primary"> Welcome :

<?php 
echo $_SESSION['email']; 
?>   
</h2>


<hr>


<div class="container">

<div class="jumbotron">


<div id="myCarousel" class="carousel slide" data-ride="carousel">
  
<ol class="carousel-indicators">
    
<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    
<li data-target="#myCarousel" data-slide-to="1"></li>
    
<li data-target="#myCarousel" data-slide-to="2"></li>
  
</ol>


  <!-- Wrapper for slides -->
  
<div class="carousel-inner">
    
<div class="item active">
      
<img src="Employe.png" alt="Digital Marketing">
    
</div>


    <div class="item">
      
<img src="emp1.jpg" alt="Android">
    
</div>

    
<div class="item">
      
<img src="Employee-.jpg" alt="Employee Management System">
    
</div>
  
</div>


  <!-- Left and right controls -->
  
<a class="left carousel-control" href="#myCarousel" data-slide="prev">
    
<span class="glyphicon glyphicon-chevron-left"></span>
    
<span class="sr-only">Previous</span>
  </a>
  
<a class="right carousel-control" href="#myCarousel" data-slide="next">
    
<span class="glyphicon glyphicon-chevron-right"></span>
    
<span class="sr-only">Next</span>
  
</a>

</div>


<code> Salary Information </code>

<code> Department Details </code>

<code> Inventory information </code>

<code> Employee Training </code>

</div>

</div>


<table class="table table-striped table-hover ">

<tr class="primary">


      <td align="center"><div class="panel panel-primary">
  
<div class="panel-heading">
    
<h3 class="panel-title">Insert Records</h3>
  
</div>
  
<div class="panel-body">

<img src="el1.jpg" width=200 height=200><br>
<a href="http://localhost/my%20php/insert.php">   
<button type="button" class="btn btn-primary">Insert</button> 
</a>
  
</div>

</div>
</td>
      
<td align="center"><div class="panel panel-warning">
  
<div class="panel-heading">
    
<h3 class="panel-title">Search Records</h3>
  
</div>
  
<div class="panel-body">

<img src="el2.jpg" width=200 height=200> 
<br>
   

<a href="http://localhost/my%20php/searchemploye.php">
<button type="button" class="btn btn-warning">Search</button>


  </a>
</div>

</div></td>


  <td align="center"><div class="panel panel-success">
  
<div class="panel-heading">
    
<h3 class="panel-title">Update</h3>
  
</div>
 

 <div class="panel-body">

<img src="el3.jpg" width=200 height=200>
<br>
   
<a href="http://localhost/my%20php/update.php">
<button type="button" class="btn btn-success">Update</button>
 
</a> 
</div>


</div></td>


  <td align="center">
<div class="panel panel-danger">
  
<div class="panel-heading">
    
<h3 class="panel-title">Delete</h3>
  
</div>
 

 <div class="panel-body">

<img src="el4.png" width=200 height=200>
<br>
   
<a href="http://localhost/my%20php/delete.php">
<button type="button" class="btn btn-danger">Delete</button>
</a>
  
</div>

</div>
</td>


</tr>

</table>


<div class="bg-info">

<a href="http://localhost/my%20php/sidebar.php"> About </a> 
|<a href="http://localhost/my%20php/location.php"> Location</a>
 
|
<a href="http://localhost/myphp/update.php"> Update </a> 
|
<a href="http://localhost/myphp/student.php"> Search </a>

<br>

<h3 style="background-color:#FFCCCB; display:inline; border-radius:10px"> 
</h3>  


</div>


</body>  

</html>